#!/usr/bin/sh
#BOS
#
# $1: Nginx_Instance_ID
test $(/usr/bin/curl -kIs https://zabbix$1.fhtdchem.com/ | /usr/bin/awk '/HTTP/ {print $2}') -eq 200 2>/dev/null && \
exit 0
#
#EOS
