#!/usr/bin/sh
#BOS
#
# $1: PostgreSQL Instance Host(0, 1, 2)
# $2: PostgreSQL Instance Port(f:2, t:1)
# $3: PostgreSQL Role(f:master, t:replica)
#
#role_result=$(echo '\\t on\nSELECT pg_is_in_recovery();\n\q' | sudo -iu postgres /usr/bin/psql -hzabbix$1 -p$((5433+10*$2)) -Upostgres 2>/dev/null)
#
role_result=$(echo '\\t on\nSELECT pg_is_in_recovery();\n\q' | /usr/bin/psql -hzabbix$1 -p$((5433+10*$2)) -Upostgres 2>/dev/null)
test x"$role_result" = x" $3" 2>/dev/null && \
exit 0
#
#EOS
