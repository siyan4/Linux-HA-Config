#!/usr/bin/sh
#BOS
#
# $1: MinIO_Instance_ID
test $(/usr/bin/curl -Is https://minio$1.fhtdchem.com:9001/ | /usr/bin/awk '/HTTP/ {print $2}') -eq 200 2>/dev/null && \
test $(/usr/bin/curl -Is https://minio$1.fhtdchem.com:8443/ | /usr/bin/awk '/HTTP/ {print $2}') -eq 200 2>/dev/null && \
exit 0
#
#EOS
